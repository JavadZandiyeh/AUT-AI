# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent


class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        currPos = currentGameState.getPacmanPosition()
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        # -----------------find required positions and distances-----------------
        # find next position of foods in newFood
        food_pos_next = newFood.asList()
        # find next distance of foods and pacman
        food_dist_next = [manhattanDistance(d, newPos) for d in food_pos_next]

        # find current position of foods
        food_pos_now = currentGameState.getFood().asList()
        # find current distance of foods and pacman
        food_dist_now = [manhattanDistance(d, currPos) for d in food_pos_now]

        # ----

        # find next position of ghosts in newGhostStates
        ghost_pos_next = [g.getPosition() for g in newGhostStates]
        # find next distance of ghosts and pacaman
        ghost_dist_next = [manhattanDistance(g, newPos) for g in ghost_pos_next]


        # --------------------------------set score--------------------------------

        # increased score from current to successor state
        score = successorGameState.getScore() - currentGameState.getScore()

        # avoid to near ghosts when they are not scared
        if min(ghost_dist_next) < 2 and sum(newScaredTimes) == 0:
            return 0
        # when score increases, it is better to do this action
        if score > 0:
            return 100
        # big dots effect
        if sum(newScaredTimes) > 0:
            return 80
        # distance from nearest food become nearer
        if min(food_dist_next) < min(food_dist_now):
            return 50
        else:
            return 20


def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)


class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        import sys
        num_agents = gameState.getNumAgents()

        # max layer of minimax
        def max_value(index, state, depth):
            if state.isWin() or state.isLose() or depth + 1 == self.depth:
                return self.evaluationFunction(state)
            v = -sys.maxsize
            legalActions = state.getLegalActions(index)
            ai = (index + 1) % num_agents  # agent index
            for action in legalActions:
                successor = state.generateSuccessor(index, action)
                v = max(v, min_value(ai, successor, depth + 1))
            return v

        # min layer of minimax
        def min_value(index, state, depth):
            if state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            v = sys.maxsize
            legalActions = state.getLegalActions(index)
            ai = (index + 1) % num_agents  # agent index
            # pacman turn
            if ai == 0:
                for action in legalActions:
                    successor = state.generateSuccessor(index, action)
                    v = min(v, max_value(ai, successor, depth))
            else:
                for action in legalActions:
                    successor = state.generateSuccessor(index, action)
                    v = min(v, min_value(ai, successor, depth))
            return v

        legalActions = gameState.getLegalActions(0)
        act = max(legalActions, key=lambda action: min_value(1, gameState.generateSuccessor(0, action), 0))
        return act


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        import sys
        num_agents = gameState.getNumAgents()

        def max_value(index, state, depth, alpha, beta):
            if state.isWin() or state.isLose() or depth+1 == self.depth:
                return self.evaluationFunction(state)
            v = -sys.maxsize
            legalActions = state.getLegalActions(index)
            a = alpha
            ai = (index + 1) % num_agents  # agent index
            for action in legalActions:
                successor = state.generateSuccessor(index, action)
                v = max(v, min_value(ai, successor, depth+1, a, beta))
                if v > beta:
                    return v
                a = max(a, v)
            return v

        def min_value(index, state, depth, alpha, beta):
            if state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            v = sys.maxsize
            legalActions = state.getLegalActions(index)
            b = beta
            ai = (index + 1) % num_agents  # agent index
            for action in legalActions:
                successor = state.generateSuccessor(index, action)
                if ai == 0:
                    v = min(v, max_value(ai, successor, depth, alpha, b))
                    if v < alpha:
                        return v
                    b = min(b, v)
                else:
                    v = min(v, min_value(ai, successor, depth, alpha, b))
                    if v < alpha:
                        return v
                    b = min(b, v)
            return v

        alpha = -sys.maxsize
        beta = sys.maxsize
        score = -sys.maxsize
        act = None
        legalActions = gameState.getLegalActions(0)
        for action in legalActions:
            state = gameState.generateSuccessor(0, action)
            if min_value(1, state, 0, alpha, beta) > score:
                act = action
                score = min_value(1, state, 0, alpha, beta)
            if score > beta:
                return act
            alpha = max(alpha, score)
        return act


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        import sys
        num_agents = gameState.getNumAgents()

        def max_value(index, state, depth):
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)
            legalActions = state.getLegalActions(index)
            v = -sys.maxsize
            ai = (index + 1) % num_agents  # agent index
            for action in legalActions:
                exp_val = expected_value(ai, state.generateSuccessor(index, action), depth+1)
                v = max(v, exp_val)
            return v

        def expected_value(index, state, depth):
            if state.isWin() or state.isLose():
                # or depth + 1 == self.depth:
                return self.evaluationFunction(state)
            legalActions = state.getLegalActions(index)
            chance = 1 / len(legalActions)
            v = 0
            ai = (index + 1) % num_agents  # agent index
            for action in legalActions:
                successor = state.generateSuccessor(index, action)
                if ai == 0:
                    v += max_value(ai, successor, depth) * chance
                else:
                    v += expected_value(ai, successor, depth) * chance
            return v

        legalActions = gameState.getLegalActions(0)
        act = None
        v = -sys.maxsize
        for action in legalActions:
            exp_val = expected_value(1, gameState.generateSuccessor(0, action), 1)
            if exp_val > v:
                v = exp_val
                act = action
        return act

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    curPos = currentGameState.getPacmanPosition()
    food_pos_now = currentGameState.getFood().asList()
    food_dist_now = [manhattanDistance(curPos, food) for food in food_pos_now]
    score = currentGameState.getScore()

    if len(food_dist_now) == 0:
        return score
    else:
        return score - min(food_dist_now)

# Abbreviation
better = betterEvaluationFunction
